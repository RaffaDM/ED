package Main;

import API.Exceptions.EmptyCollectionException;
import API.Leitura.APILeitura;
import Classes.Jogo;
import Classes.MissaoManual;
import Classes.MissoesExporter;
import Classes.MissoesRealizadas;
import Classes.ReadMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.parser.ParseException;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class demo {

    public static void main(String[] args) throws IOException, ParseException, EmptyCollectionException {
        try {

            int choiceMap = 0, choiceGameType = 0;
            APILeitura apiLeitura = new APILeitura();
            File directoryPath = new File("Mapas");
            String contents[] = directoryPath.list();

            for (int i = 0; i < directoryPath.list().length; i++) {
                System.out.println(i + " -> " + directoryPath.list()[i].toString());
            }
            choiceMap = apiLeitura.readInt(0, directoryPath.list().length - 1, "Qual o mapa que quer escolher?");

            ReadMap map = new ReadMap("Mapas\\" + directoryPath.list()[choiceMap].toString());
            Jogo jogo = map.getMapa();
            MissaoManual missaoManual = new MissaoManual();
            MissoesRealizadas missoesRealizadas = new MissoesRealizadas(jogo.getCod_missao(), jogo.getVersao());
            MissoesExporter exporterMissoes = new MissoesExporter();

            while (choiceGameType != 3) {

                choiceGameType = apiLeitura.readInt(0, 3, "0-> Modo Manual  || 1-> Modo Automático || 2-> Gravar Missoes Manuais|| 3-> Sair do Jogo");
                switch (choiceGameType) {
                    case 0:
                        missaoManual = jogo.startGameManual();
                        missoesRealizadas.addMissaoManual(missaoManual);
                        break;
                    case 1:
                        jogo.startGameAutomatic();
                        break;
                    case 2:
                        exporterMissoes.export(missoesRealizadas);
                        break;
                    
                    default:
                        
                        System.out.println("A sair....");

                }
            }

        } catch (FileNotFoundException ex) {
            System.out.println(ex.toString());
        } catch (IOException | ParseException ex) {
            System.out.println(ex.toString());
        }

    }
}
