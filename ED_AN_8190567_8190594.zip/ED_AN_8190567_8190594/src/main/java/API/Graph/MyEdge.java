package API.Graph;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class MyEdge {

    private int posicion;
    private int weight;

    public MyEdge(int posicion, int weight) {
        this.posicion = posicion;
        this.weight = weight;
    }

    public MyEdge(int posicion) {
        this.posicion = posicion;
        this.weight = 0;
    }

    public MyEdge() {
        this.posicion = 0;
        this.weight = 0;
    }

    /**
     * Gets the posicion of the vertex that are connected
     *
     * @return posicion
     */
    public int getPosicion() {
        return posicion;
    }

    /**
     * Sets the posicion of the vertex thar are connected
     *
     * @param posicion - posicion
     */
    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }
/**
 * Gets the cost of the edge
 * @return the cost of the edge
 */
    public int getWeight() {
        return weight;
    }
/**
 * Sets the cost of the edge
 * @param weight - weight
 */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "" + posicion;
    }

}
