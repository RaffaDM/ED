package API.Graph;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class GraphNode<T> {

    private final int TAM_ADJ_VERTEX = 5;
    private T element;
    protected MyEdge adjVertex[];
    private int count;

    public GraphNode(T element) {
        this.element = element;
        this.adjVertex = new MyEdge[TAM_ADJ_VERTEX];
        this.count = 0;
    }

    public GraphNode() {
        this.element = null;
        this.adjVertex = new MyEdge[TAM_ADJ_VERTEX];
        this.count = 0;
    }

    /**
     * Gets the adjVertex(the vertex's that the vertex are conected)
     *
     * @return the adjVertex
     */
    public MyEdge[] getAdjVertex() {
        return adjVertex;
    }

    /**
     * Expand the capacity of the conections(adjVertex)
     */
    private void expandCapacity() {
        MyEdge[] temp;
        temp = new MyEdge[adjVertex.length * 2];

        System.arraycopy(adjVertex, 0, temp, 0, count);
        adjVertex = temp;
    }

    /**
     * adds and edge between to vertexs
     *
     * @param posicion - posicion of the vertex to connect
     */
    public void addEdge(int posicion) {
        if (count == adjVertex.length) {
            expandCapacity();
        }
        adjVertex[count] = new MyEdge(posicion);
        count++;
    }

    /**
     * adds and edge between to vertexs
     *
     * @param posicion - posicion of the vertex to connect
     * @param weight - the cost of the connection
     */
    public void addEdge(int posicion, int weight) {
        if (count == adjVertex.length) {
            expandCapacity();
        }
        adjVertex[count] = new MyEdge(posicion, weight);
        count++;
    }

    /**
     * Finds the edge
     *
     * @param edge - the edge
     * @return -1 if doesn't exist, greater/equal 0 if exits
     */
    private int find(int edge) {
        for (int i = 0; i < count; i++) {
            if (adjVertex[i].getPosicion() == edge) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Removes the edge
     *
     * @param edge - edge to remove
     */
    public void removeEdge(int edge) {
        int posicion = find(edge);

        if (posicion != -1) {
            for (int i = posicion; i < count; i++) {
                adjVertex[i] = adjVertex[i + 1];
            }
            count--;
        }
    }

    /**
     * Get the element of the node
     *
     * @return element
     */
    public T getElement() {
        return element;
    }

    /**
     * Set the element
     *
     * @param element - element to set
     */
    public void setElement(T element) {
        this.element = element;
    }

    /**
     * Size of adjVertex
     *
     * @return the size of adjVertex
     */
    public int size() {
        return count;
    }

    @Override
    public String toString() {
        return element.toString();
    }
}
