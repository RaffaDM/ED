package API.Graph;

import API.ArrayUnorderedList.ArrayUnorderedList;
import API.Exceptions.EmptyCollectionException;
import API.PriorityQueue.PriorityQueue;
import API.Queue.LinkedQueue;
import API.Stack.LinkedStack;
import java.util.Iterator;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class Graph_List<T extends Comparable> implements GraphADT<T> {

    protected final int DEFAULT_CAPACITY = 10;
    protected int numVertices; // number of vertices in the graph
    protected GraphNode<T>[] vertices; // values of vertices 

    public Graph_List() {
        numVertices = 0;
        this.vertices = new GraphNode[DEFAULT_CAPACITY];
    }

    /**
     * Expands the capacity of the array of vertices
     */
    private void expandCapacity() {
        GraphNode<T>[] temp;
        temp = new GraphNode[vertices.length * 2];

        System.arraycopy(vertices, 0, temp, 0, numVertices);
        vertices = temp;
    }

    /**
     * Returns false if the index in invalid
     *
     * @param index - index to analyse
     * @return true if index is above/equal 0 and lower then the numOfVertices and
     * different of null on the vertice[index] or false if not
     */
    protected boolean indexIsValid(int index) {
        return index >= 0 && index < numVertices && vertices[index] != null;
    }

    /**
     * Get the index of the vertex
     *
     * @param vertex - vertex to analyse
     * @return the index of the vertex
     */
    protected int getIndex(T vertex) {
        for (int i = 0; i < size(); i++) {
            if (vertices[i].getElement().compareTo(vertex) == 0) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Adds a vertex to this graph, associating object with vertex.
     *
     * @param vertex the vertex to be added to this graph
     */
    @Override
    public void addVertex(T vertex) {
        if (numVertices == vertices.length) {
            expandCapacity();
        }
        GraphNode<T> node = new GraphNode<>(vertex);
        vertices[numVertices] = node;
        numVertices++;
    }

    /**
     * Removes a single vertex with the given value from this graph.
     *
     * @param vertex the vertex to be removed from this graph
     */
    @Override
    public void removeVertex(T vertex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Inserts an edge between two vertices of this graph.
     *
     * @param vertex1 the first vertex
     * @param vertex2 the second vertex
     */
    @Override
    public void addEdge(T vertex1, T vertex2) {
        int index1 = getIndex(vertex1);
        int index2 = getIndex(vertex2);
        if (indexIsValid(index1) && indexIsValid(index2)) {
            vertices[index1].addEdge(index2);
        }
    }

    /**
     * Returns an iterator that contains the shortest path between the two
     * vertices.
     *
     * @param vertex1 the starting vertex
     * @param vertex2 the ending vertex
     * @param weight the cost of the edge
     *
     */
    @Override
    public void addEdge(T vertex1, T vertex2, int weight) {
        if (weight >= 0) {
            int index1 = getIndex(vertex1);
            int index2 = getIndex(vertex2);
            if (indexIsValid(index1) && indexIsValid(index2)) {
                vertices[index1].addEdge(index2, weight);
            }
        }
    }

    /**
     * Removes an edge between two vertices of this graph.
     *
     * @param vertex1 the first vertex
     * @param vertex2 the second vertex
     */
    @Override
    public void removeEdge(T vertex1, T vertex2) {
        int index1 = getIndex(vertex1);
        int index2 = getIndex(vertex2);
        if (indexIsValid(index1) && indexIsValid(index2)) {
            vertices[index1].removeEdge(index2);
        }
    }

    /**
     * Returns an iterator that performs a breadth first search traversal
     * starting at the given index.
     *
     * @param startVertex the index to begin the search from
     * @return an iterator that performs a breadth first traversal
     */
    @Override
    public Iterator iteratorBFS(T startVertex) {
        int startIndex = getIndex(startVertex);
        Integer x;
        LinkedQueue<Integer> traversalQueue = new LinkedQueue<>();
        ArrayUnorderedList<String> resultList = new ArrayUnorderedList<>(size());

        if (!indexIsValid(startIndex)) {
            return resultList.iterator();
        }

        boolean[] visited = new boolean[numVertices];

        for (int i = 0; i < numVertices; i++) {
            visited[i] = false;
        }

        traversalQueue.enqueue(new Integer(startIndex));
        visited[startIndex] = true;
        int posicion;

        while (!traversalQueue.isEmpty()) {
            x = traversalQueue.dequeue();
            resultList.addToRear(vertices[x.intValue()].toString());
            for (int i = 0; i < numVertices && vertices[x.intValue()].getAdjVertex()[i] != null; i++) {
                if (!visited[vertices[x.intValue()].getAdjVertex()[i].getPosicion()]) {
                    posicion = vertices[x.intValue()].getAdjVertex()[i].getPosicion();
                    traversalQueue.enqueue(new Integer(posicion));
                    visited[posicion] = true;
                }
            }
        }

        return resultList.iterator();
    }

    /**
     * Returns an iterator that performs a depth first search traversal starting
     * at the given index.
     *
     * @param startVertex the index to begin the search traversal from
     * @return an iterator that performs a depth first traversal
     * @throws API.Exceptions.EmptyCollectionException -  if the collection is empty
     */
    @Override
    public Iterator iteratorDFS(T startVertex) throws EmptyCollectionException{

        int startIndex = getIndex(startVertex);
        Integer x;
        boolean found;
        boolean[] visited = new boolean[numVertices];
        LinkedStack<Integer> traversalStack = new LinkedStack<Integer>();
        ArrayUnorderedList<String> resultList = new ArrayUnorderedList<>(size());

        if (!indexIsValid(startIndex)) {
            return resultList.iterator();
        }
        for (int i = 0; i < numVertices; i++) {
            visited[i] = false;
        }

        traversalStack.push(new Integer(startIndex));
        resultList.addToRear(vertices[startIndex].toString());
        visited[startIndex] = true;
        int posicion;

        while (!traversalStack.isEmpty()) {
            x = traversalStack.peek();
            found = false;

            for (int i = 0; (i < numVertices && vertices[x.intValue()].getAdjVertex()[i] != null) && !found; i++) {

                if (!visited[vertices[x.intValue()].getAdjVertex()[i].getPosicion()]) {
                    posicion = vertices[x.intValue()].getAdjVertex()[i].getPosicion();
                    found = true;
                    visited[posicion] = true;
                    traversalStack.push(posicion);
                    resultList.addToRear(vertices[posicion].toString());

                }
            }
            if (!found && !traversalStack.isEmpty()) {
                traversalStack.pop();
            }
        }

        return resultList.iterator();
    }

    /**
     * Returns Table of Diklstra
     *
     * @param startIndex - the starting vertex
     * @return an table of dijkstra all shortest paths from the startIndex node
     * @throws EmptyCollectionException - if the collection is empty
     */
    private TabelaDijkstra dijkstra(int startIndex) throws EmptyCollectionException {

        int index = 0, minValue = 0;
        PriorityQueue<Integer> pq = new PriorityQueue<>();
        boolean[] visited = new boolean[numVertices];
        int prev[] = new int[numVertices];
        int dist[] = new int[numVertices];
        int cost = 0;

        for (int i = 0; i < numVertices; i++) {
            visited[i] = false;
            dist[i] = Integer.MAX_VALUE;
            prev[i] = -1;
        }

        dist[startIndex] = 0;
        pq.addElement(startIndex, 0);
        
        while (pq.size() != 0) {
            index =  pq.removeNext();
            visited[index] = true;

            for (int i = 0; i < vertices[index].size(); i++) {
                if (!visited[vertices[index].getAdjVertex()[i].getPosicion()]) {
                    cost = dist[index] + vertices[index].getAdjVertex()[i].getWeight();
                }
                if (cost < dist[vertices[index].getAdjVertex()[i].getPosicion()]) {
                    prev[vertices[index].getAdjVertex()[i].getPosicion()] = index;
                    dist[vertices[index].getAdjVertex()[i].getPosicion()] = cost;
                    pq.addElement(vertices[index].getAdjVertex()[i].getPosicion(), cost);
                }
            }

        }
        return new TabelaDijkstra(prev, dist);
    }

    /**
     * Returns an iterator that contains the shortest path between the two
     * vertices.
     *
     * @param startVertex the starting vertex
     * @param targetVertex the ending vertex
     * @return an iterator that contains the shortest path between the two
     * vertices
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public Iterator iteratorShortestPath(T startVertex, T targetVertex) throws EmptyCollectionException {
        int startIndex = getIndex(startVertex);
        int targetIndex = getIndex(targetVertex);

        TabelaDijkstra tabela = dijkstra(startIndex);
        LinkedStack<String> temp = new LinkedStack<>();
        ArrayUnorderedList<String> path = new ArrayUnorderedList<>(vertices.length);
        if (tabela.getDist()[targetIndex] == Integer.MAX_VALUE) {
            System.out.println("ERRO ERRO LINHA 214 GRAPH LIST");
        } else {
            for (int i = targetIndex; i != -1; i = tabela.getPrev()[i]) {

                temp.push(vertices[i].getElement().toString());
            }
            for (int i = temp.size(); i > 0; i--) {
                path.addToRear(temp.pop());
            }
        }
        return path.iterator();
    }

    /**
     * Returns true if this graph is empty, false otherwise.
     *
     * @return true if this graph is empty
     */
    @Override
    public boolean isEmpty() {
        return numVertices == 0;
    }

    /**
     * Returns true if this graph is connected, false otherwise.
     *
     * @return true if this graph is connected
     */
    @Override
    public boolean isConnected() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Returns the number of vertices in this graph.
     *
     * @return the integer number of vertices in this graph
     */
    @Override
    public int size() {
        return numVertices;
    }

    public GraphNode<T>[] getVertices() {
        return vertices;
    }

}
