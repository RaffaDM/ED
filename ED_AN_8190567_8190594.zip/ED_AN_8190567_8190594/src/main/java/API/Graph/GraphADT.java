package API.Graph;

import API.Exceptions.EmptyCollectionException;
import java.util.Iterator;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface GraphADT<T> {

    /**
     * Adds a vertex to this graph, associating object with vertex.
     *
     * @param vertex the vertex to be added to this graph
     */
    public void addVertex(T vertex);

    /**
     * Removes a single vertex with the given value from this graph.
     *
     * @param vertex the vertex to be removed from this graph
     */
    public void removeVertex(T vertex);

    /**
     * Inserts an edge between two vertices of this graph.
     *
     * @param vertex1 the first vertex
     * @param vertex2 the second vertex
     */
    public void addEdge(T vertex1, T vertex2);

    /**
     * Returns an iterator that contains the shortest path between the two
     * vertices.
     *
     * @param vertex1 the starting vertex
     * @param vertex2 the ending vertex
     * @param weight the cost of the edge
     *
     */
    public void addEdge(T vertex1, T vertex2, int weight);

    /**
     * Removes an edge between two vertices of this graph.
     *
     * @param vertex1 the first vertex
     * @param vertex2 the second vertex
     */
    public void removeEdge(T vertex1, T vertex2);

    /**
     * Returns an iterator that performs a breadth first search traversal
     * starting at the given index.
     *
     * @param startVertex the index to begin the search from
     * @return an iterator that performs a breadth first traversal
     */
    public Iterator iteratorBFS(T startVertex);

    /**
     * Returns an iterator that performs a depth first search traversal starting
     * at the given index.
     *
     * @param startVertex the index to begin the search traversal from
     * @return an iterator that performs a depth first traversal
     * @throws API.Exceptions.EmptyCollectionException if the collection is empty
     */
    public Iterator iteratorDFS(T startVertex) throws EmptyCollectionException;

    /**
     * Returns an iterator that contains the shortest path between the two
     * vertices.
     *
     * @param startVertex the starting vertex
     * @param targetVertex the ending vertex
     * @return an iterator that contains the shortest path between the two
     * vertices
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    public Iterator iteratorShortestPath(T startVertex, T targetVertex) throws EmptyCollectionException;

    /**
 * Returns true if this graph is empty, false otherwise.
 *
 * @return true if this graph is empty
 */
    public boolean isEmpty();

    /**
 * Returns true if this graph is connected, false otherwise.
 *
 * @return true if this graph is connected
 */
    public boolean isConnected();

    /**
     * Returns the number of vertices in this graph.
     *
     * @return the integer number of vertices in this graph
     */
    public int size();

    @Override
    public String toString();
}
