package API.Queue;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class LinkedQueue<T> implements QueueADT<T> {

    private int count;
    private LinkedNode<T> front;
    private LinkedNode<T> rear;

    public LinkedQueue() {
        this.count = 0;
        front = null;
        rear = null;
    }

    /**
     * Adds one element to the rear of this queue.
     *
     * @param element the element to be added to the rear of this queue
     */
    @Override
    public void enqueue(T element) {
        LinkedNode<T> node = new LinkedNode<T>(element);
        if (isEmpty()) {
            front = node;
            rear = node;
        } else {
            rear.setNext(node);
            rear = node;
        }
        count++;
    }

    /**
     * Removes and returns the element at the front of this queue.
     *
     * @return the element at the front of this queue
     */
    @Override
    public T dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty, can't dequeue");
        }
        LinkedNode<T> temp = front;
        front = front.getNext();
        count--;
        return temp.getData();
    }

    /**
     * Returns without removing the element at the front of this queue.
     *
     * @return the first element in this queue
     */
    @Override
    public T first() {
        return front.getData();
    }

    /**
     * Returns true if this queue contains no elements.
     *
     * @return true if this queue is empty
     */
    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    /**
     * Returns the number of elements in this queue.
     *
     * @return the integer representation of the size of this queue
     */
    @Override
    public int size() {
        return count;
    }

    @Override
    public String toString() {
        LinkedNode<T> temp = new LinkedNode<>();
        temp = front;
        String s = "";
        while (temp != null) {
            s += temp.getData() + "->";
            temp = temp.getNext();
        }
        return s;
    }
}
