package API.ArrayUnorderedList;

import API.Exceptions.EmptyCollectionException;
import java.util.Iterator;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public abstract class ArrayList<T> implements ListADT<T> {

    private final int TAM_LIST = 10;
    protected T[] list;
    protected int rear;

    public ArrayList() {
        list = (T[]) new Object[TAM_LIST];
        rear = 0;
    }

    public ArrayList(int capacity) {
        list = (T[]) new Object[capacity];
        rear = 0;
    }

    /**
     * Expand the capacity of the array
     */
    protected void expandCapacity() {
        T[] temp;
        temp = (T[]) new Object[list.length * 2];

        System.arraycopy(list, 0, temp, 0, rear);
        list = temp;
    }

    /**
     * Finds the element
     *
     * @param element - element that's gonna be found
     * @return -1 if doesn't exist, or greater/equal 0 if exists
     */
    public int find(T element) {

        for (int i = 0; i < rear; i++) {
            if (list[i].equals(element)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Removes and returns the first element from this list.
     *
     * @return the first element from this list
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public T removeFirst() throws EmptyCollectionException {

        if (isEmpty()) {
            throw new EmptyCollectionException();
        }

        T temp = list[0];
        for (int i = 0; i < rear - 1; i++) {
            list[i] = list[i + 1];
        }
        rear--;
        list[rear] = null;

        return temp;
    }

    /**
     * Removes and returns the last element from this list.
     *
     * @return the last element from this list
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public T removeLast() throws EmptyCollectionException {

        if (isEmpty()) {
            throw new EmptyCollectionException();
        }
        if (!isEmpty()) {
            T temp = list[rear - 1];
            list[rear - 1] = null;
            rear--;
            return temp;
        }
        return null;
    }

    /**
     * Removes and returns the specified element from this list.
     *
     * @param element the element to be removed from the list
     * @return the element removed
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public T remove(T element) throws EmptyCollectionException {

        if (isEmpty()) {
            throw new EmptyCollectionException();
        }

        if (contains(element)) {
            for (int i = find(element); i < rear - 1; i++) {
                list[i] = list[i + 1];
            }
            list[rear - 1] = null;
            rear--;
            return element;
        }
        return null;
    }

    /**
     * Returns a reference to the first element in this list.
     *
     * @return a reference to the first element in this list
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public T first() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Empty Array");
        }
        return list[0];
    }

    /**
     * Returns a reference to the last element in this list.
     *
     * @return a reference to the last element in this list
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empt
     */
    @Override
    public T last() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Empty Array");
        }
        return list[rear - 1];
    }

    /**
     * Returns true if this list contains the specified target element.
     *
     * @param target the target that is being sought in the list
     * @return true if the list contains this element
     */
    @Override
    public boolean contains(T target) {
        // se for -1 então não existe, mas se for diferente quer dizer que existe
        return find(target) != -1;
    }

    /**
     * Returns true if this list contains no elements.
     *
     * @return true if this list contains no elements
     */
    @Override
    public boolean isEmpty() {
        return rear == 0;
    }

    /**
     * Returns the number of elements in this list.
     *
     * @return the integer representation of number of elements in this list
     */
    @Override
    public int size() {
        return rear;
    }

    /**
     * Returns an iterator for the elements in this list.
     *
     * @return an iterator over the elements in this list
     */
    @Override
    public Iterator<T> iterator() {
        return new ArrayIterator<>(list, rear);
    }

}
