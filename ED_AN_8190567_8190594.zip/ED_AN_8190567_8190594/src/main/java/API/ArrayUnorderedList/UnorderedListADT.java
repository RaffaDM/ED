package API.ArrayUnorderedList;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface UnorderedListADT<T> extends ListADT<T> {

    /**
     * adds a element to the front of the list
     *
     * @param element - element to add
     */
    public void addToFront(T element);

    /**
     * adds a element to the rear of the list
     *
     * @param element - element to add
     */
    public void addToRear(T element);

    /**
     * adds after an specific element
     *
     * @param element - element to add
     * @param target - add after target
     */
    public void addAfter(T element, T target);
}
