package API.ArrayUnorderedList;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class ArrayUnorderedList<T> extends ArrayList<T> implements UnorderedListADT<T> {

    public ArrayUnorderedList() {
        super();
    }

    public ArrayUnorderedList(int capacity) {
        super(capacity);
    }

    /**
     * adds a element to the front of the list
     *
     * @param element - element to add
     */
    @Override
    public void addToFront(T element) {
        if (element != null) {
            if (rear >= size()) {
                expandCapacity();
            }
            if (isEmpty()) {
                list[rear] = element;
            }

            for (int i = rear; i > 0; i--) {
                list[i] = list[i - 1];
            }
            list[0] = element;

            rear++;
        }
    }

    /**
     * adds a element to the rear of the list
     *
     * @param element - element to add
     */
    @Override
    public void addToRear(T element) {
        if (rear > list.length) {
            expandCapacity();
        }
        if (element != null) {
            list[rear] = element;
            rear++;
        }
    }

    /**
     * adds after an specific element
     *
     * @param element - element to add
     * @param target - add after target
     */

    @Override
    public void addAfter(T element, T target) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        String s = "";

        for (int i = 0; i < rear; i++) {
            s += "" + list[i] + "\n";
        }
        return s;
    }

}
