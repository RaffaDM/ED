package API.Leitura;

import java.util.Scanner;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class APILeitura implements APILeituraADT {

    public APILeitura() {
    }

    /**
     * Reads a int number directly from the console
     *
     * @param min - min value to insert
     * @param max - max value to insert
     * @param message - Message to show
     * @return the int value inserted
     */
    @Override
    public int readInt(int min, int max, String message) {
        int var = -1;
        boolean flag = false;

        Scanner in = new Scanner(System.in);
        System.out.println(message);

        while (!flag) {

            if (in.hasNextInt()) {
                var = in.nextInt();
            } else {
                System.out.println("Invalid input. Please try again.");
                in.next();
                System.out.println();
            }
            if (var > max || var < min) {
                System.out.println("Insira o valor novamente, entre " + min + " e " + max);
            } else {
                flag = true;
            }
        }
        in.nextLine();
        return var;
    }

}
