package API.Leitura;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface APILeituraADT {

    /**
     * Reads a int number directly from the console
     *
     * @param min - min value to insert
     * @param max - max value to insert
     * @param message - Message to show
     * @return the int value inserted
     */
    public int readInt(int min, int max, String message);

}
