package API.Exceptions;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class EmptyCollectionException extends Exception {

    public EmptyCollectionException() {
    }

    public EmptyCollectionException(String msg) {
        super(msg);
    }
}
