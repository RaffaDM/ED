package API.Heap;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class HeapNode<T> extends BinaryTreeNode<T> {

    protected HeapNode<T> parent;

    public HeapNode(T element) {
        super(element);
        parent = null;
    }

    /**
     * Get the parent of the node
     *
     * @return the parent
     */
    public HeapNode<T> getParent() {
        return parent;
    }

    /**
     * Set the parent of the node
     *
     * @param parent - the node that is gonna be is parent
     */
    public void setParent(HeapNode<T> parent) {
        this.parent = parent;
    }

}
