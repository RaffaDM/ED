package API.Stack;

import API.Exceptions.EmptyCollectionException;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class LinkedStack<T> implements StackADT<T> {

    private int count;
    private LinkedNode<T> top;

    public LinkedStack() {
        this.count = 0;
        this.top = null;
    }

    /**
     * Adds one element to the top of this stack.
     *
     * @param element element to be pushed onto stack
     */
    @Override
    public void push(T element) {
        LinkedNode<T> node = new LinkedNode<>(element);

        node.setNext(top);
        top = node;
        count++;
    }

    /**
     * Removes and returns the top element from this stack.
     *
     * @return T element removed from the top of the stack
     * @throws API.Exceptions.EmptyCollectionException - if the collection is empty
     */
    @Override
    public T pop() throws EmptyCollectionException{
        if (isEmpty()) {
           throw new EmptyCollectionException("Stack vazia");
        }

        LinkedNode<T> temp = top;
        top = top.getNext();
        count--;
        return temp.getData();
    }

    /**
     * Returns without removing the top element of this stack.
     *
     * @return T element on top of the stack
     */
    @Override
    public T peek() {
        return top.getData();
    }

    /**
     * Returns true if this stack contains no elements.
     *
     * @return boolean whether or not this stack is empty
     */
    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    /**
     * Returns the number of elements in this stack.
     *
     * @return int number of elements in this stack
     */
    @Override
    public int size() {
        return count;
    }

    @Override
    public String toString() {
        LinkedNode<T> temp = new LinkedNode<>();
        temp = top;
        String s = "";
        while (temp != null) {
            s += temp.getData() + "->";
            temp = temp.getNext();
        }
        return s;
    }
}
