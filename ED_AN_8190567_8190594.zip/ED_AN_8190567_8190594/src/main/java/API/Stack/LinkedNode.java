package API.Stack;


/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public class LinkedNode<T> {

    private T data;
    private LinkedNode<T> next;

    public LinkedNode() {
        this.data = null;
        this.next = null;

    }

    public LinkedNode(T data) {
        this.data = data;
        this.next = null;

    }

    public T getData() {
        return data;
    }

    public LinkedNode<T> getNext() {
        return next;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setNext(LinkedNode<T> next) {
        this.next = next;
    }

    @Override
    public String toString() {
        //return ""+ this.data + " "+ getNext() ;
        return "" + this.getData() + " ";
    }

}
