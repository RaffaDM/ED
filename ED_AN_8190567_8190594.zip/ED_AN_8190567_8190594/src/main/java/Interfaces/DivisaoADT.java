package Interfaces;

import Classes.Inimigo;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface DivisaoADT {

    /**
     * Add a new enemy to inimigo array
     *
     * @param nome - Name of the enemy
     * @param poder - Power of the enemy
     * @param divisao - division where enemy is
     * @throws NullPointerException if the variables are equals a null
     */
    public void addInimigo(String nome, int poder, String divisao) throws NullPointerException;

    /**
     * Add a new enemy to inimigo array
     *
     * @param inimigo - Enemy
     * @throws NullPointerException if the variables are equals a null
     */
    public void addInimigo(Inimigo inimigo) throws NullPointerException;

    /**
     * Returns the size of inimigos array
     *
     * @return the size of inimigos array
     */
    public int size();

    /**
     * Returns the total damage taken from the enemy/enemys on the division
     *
     * @return the total damge taken
     */
    public int danoInimigos();
}
