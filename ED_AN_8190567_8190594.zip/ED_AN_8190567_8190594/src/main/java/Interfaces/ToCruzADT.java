package Interfaces;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface ToCruzADT {

    /**
     * Returns if toCruz have the alvo
     *
     * @return if toCruz have the alvo, return true, if not, return false
     */
    public boolean isAlvo();

    /**
     * Set if toCruz have the alvo
     *
     * @param alvo - boolean alvo
     */
    public void setAlvo(boolean alvo);

    /**
     * Removes life points of toCruz
     *
     * @param dano - damage dealt
     */
    public void levouBala(int dano);

    /**
     * Returns if toCruz is dead
     *
     * @return true if toCruz is dead, false if he is alive
     */
    public boolean isDead();

    /**
     * Gets the constant max life points
     *
     * @return the Max life points
     */
    public int getTAM_VIDA();
}
