package Interfaces;

import API.Exceptions.EmptyCollectionException;
import Classes.MissaoManual;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
public interface JogoADT {

    /**
     * Starts the game in automaticc mode
     *
     * @throws EmptyCollectionException - if the the collection is empty
     */
    public void startGameAutomatic() throws EmptyCollectionException;

    /**
     * Start the game on manual mode
     * @return The mission brief
     */
    public MissaoManual startGameManual();
}
