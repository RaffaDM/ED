package Classes;

import Interfaces.ToCruzADT;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 * ToCruz is the agent who will walk between divisions, so he will take damage
 * from enemies and will get the alvo.
 */
public class ToCruz implements ToCruzADT {

    private final int TAM_VIDA = 100;
    private int vida;
    private boolean alvo;

    public ToCruz() {
        this.vida = TAM_VIDA;
        this.alvo = false;

    }

    /**
     * Get the life of toCruz
     *
     * @return life of toCruz
     */
    public int getVida() {
        return vida;
    }

    /**
     * Set the life of toCruz #give another chance to live :)
     *
     * @param vida - the life
     */
    public void setVida(int vida) {
        this.vida = vida;
    }

    /**
     * Returns if toCruz have the alvo
     *
     * @return if toCruz have the alvo, return true, if not, return false
     */
    @Override
    public boolean isAlvo() {
        return alvo;
    }

    /**
     * Set if toCruz have the alvo
     *
     * @param alvo - boolean alvo
     */
    @Override
    public void setAlvo(boolean alvo) {
        this.alvo = alvo;
    }

    /**
     * Removes life points of toCruz
     *
     * @param dano - damage dealt
     */
    @Override
    public void levouBala(int dano) {
        vida -= dano;
    }

    /**
     * Returns if toCruz is dead
     *
     * @return true if toCruz is dead, false if he is alive
     */
    @Override
    public boolean isDead() {
        return getVida() < 0;
    }

    /**
     * Gets the constant max life points
     *
     * @return the Max life points
     */
    @Override
    public int getTAM_VIDA() {
        return TAM_VIDA;
    }

}
