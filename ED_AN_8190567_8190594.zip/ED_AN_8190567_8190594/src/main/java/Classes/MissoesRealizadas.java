package Classes;

import API.PriorityQueue.PriorityQueue;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * All mission realyzed my toCruz in manual mode
 */
public class MissoesRealizadas {

    private String cod_missao;
    private int versao;
    private PriorityQueue<MissaoManual> missoesManuais;

    public MissoesRealizadas(String cod_missao, int versao) {
        this.cod_missao = cod_missao;
        this.versao = versao;
        missoesManuais = new PriorityQueue<>();
    }

    public MissoesRealizadas() {
    }

    /**
     * Get the cod misson
     *
     * @return the cod mission
     */
    public String getCod_missao() {
        return cod_missao;
    }

    /**
     * Set cod mission
     *
     * @param cod_missao - cod mission
     */
    public void setCod_missao(String cod_missao) {
        this.cod_missao = cod_missao;
    }

    /**
     * Get the version
     *
     * @return - version of game
     */
    public int getVersao() {
        return versao;
    }

    /**
     * Set the version
     *
     * @param versao - version
     */
    public void setVersao(int versao) {
        this.versao = versao;
    }

    /**
     * Gets the priorityQueue
     *
     * @return the priorityQueue
     */
    public PriorityQueue<MissaoManual> getMissoesManuais() {
        return missoesManuais;
    }

    /**
     * adds a manual mission
     *
     * @param missao - the manual mission to add
     */
    public void addMissaoManual(MissaoManual missao) {

        missoesManuais.addElement(missao, 100 - missao.getVidaRestante());
    }

}
