package Classes;

import Interfaces.DivisaoADT;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * Divisions it's all the rooms inside the building, so To Cruz will walk
 * between them, it will exist many tips of Division: Division with To Cuz;
 * Division without To Cruz; Division with Alvo; Division with enemy; Division
 * with enemy and Alvo; Division with To Cruz and enemy; Division with To Cuz
 * and Alvo.
 *
 */
public class Divisao implements Comparable, DivisaoADT {

    private String nome;
    private Inimigo[] inimigos;
    private int nInimigos;
    private final int DEFAULT_TAM = 2;
    private boolean entrada_saida;
    private boolean alvo;

    public Divisao() {
        this.nome = "";
        inimigos = new Inimigo[DEFAULT_TAM];
        entrada_saida = false;
        alvo = false;
    }

    public Divisao(String nome) {
        this.nome = nome;
        inimigos = new Inimigo[DEFAULT_TAM];
        entrada_saida = false;
        alvo = false;
    }

    public Divisao(String nome, int customTam) {
        this.nome = nome;
        inimigos = new Inimigo[customTam];
        entrada_saida = false;
        alvo = false;
    }

    /**
     * Expands the capacity of the array inimigo
     */
    private void expandCapacity() {
        Inimigo[] temp;
        temp = (Inimigo[]) new Object[inimigos.length * 2];

        System.arraycopy(inimigos, 0, temp, 0, nInimigos);
        inimigos = temp;
    }

    /**
     * Add a new enemy to inimigo array
     *
     * @param nome - Name of the enemy
     * @param poder - Power of the enemy
     * @param divisao - division where enemy is
     * @throws NullPointerException - if the variables are equals a null
     */
    @Override
    public void addInimigo(String nome, int poder, String divisao) throws NullPointerException {
        if (nome == null || divisao == null) {
            throw new NullPointerException();
        }
        if (size() == inimigos.length) {
            expandCapacity();
        }
        this.inimigos[nInimigos] = new Inimigo(nome, poder, divisao);
        nInimigos++;

    }

    /**
     * Add a new enemy to inimigo array
     *
     * @param inimigo - Enemy
     * @throws NullPointerException if the variables are equals a null
     */
    @Override
    public void addInimigo(Inimigo inimigo) throws NullPointerException {
        if (inimigo == null) {
            throw new NullPointerException();
        }
        if (size() == inimigos.length) {
            expandCapacity();
        }
        this.inimigos[nInimigos] = inimigo;
        nInimigos++;

    }

    /**
     * Returns the size of inimigos array
     *
     * @return the size of inimigos array
     */
    @Override
    public int size() {
        return nInimigos;
    }

    /**
     * Returns the total damage taken from the enemy/enemys on the division
     *
     * @return the total damge taken
     */
    @Override
    public int danoInimigos() {
        int balas = 0;
        for (int i = 0; i < nInimigos; i++) {
            balas += inimigos[i].getPoder();
        }
        return balas;
    }

    /**
     *
     * {@inheritDoc}
     */
    @Override
    public int compareTo(Object obj) {
        int equal = -1;
        if (obj == null) {
            throw new NullPointerException();
        }
        if (obj.getClass() == getClass()) {
            Divisao temp = (Divisao) obj;
            if (temp.nome.compareTo(nome) == 0) {
                equal = 0;
            }
        }
        return equal;
    }

    /**
     *
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Divisao other = (Divisao) obj;
        if (this.nInimigos != other.nInimigos) {
            return false;
        }
        if (this.DEFAULT_TAM != other.DEFAULT_TAM) {
            return false;
        }

        return true;
    }

    /**
     * If nInimigos is greater then 0, it means that the division have enemys
     *
     * @return true if the division have enemys, false if not
     */
    public boolean isInimigos() {
        return nInimigos > 0;
    }

    /**
     * Returns the array of enemys
     *
     * @return array of enemys
     */
    public Inimigo[] getInimigos() {
        return inimigos;
    }

    /**
     * Returns if the division it's a entry/exit
     *
     * @return true if it's a entry/exit, false if it's not
     */
    public boolean isEntrada_saida() {
        return entrada_saida;
    }

    /**
     * Set true if it´s a entry/exit, false if isn't
     *
     * @param entrada_saida - boolean value
     */
    public void setEntrada_saida(boolean entrada_saida) {
        this.entrada_saida = entrada_saida;
    }

    /**
     * Returns if the division have the alvo
     *
     * @return true if the division have the alvo, false if it's not
     */
    public boolean isAlvo() {
        return alvo;
    }

    /**
     * Set if the division have the alvo or not
     *
     * @param alvo -boolean value
     */
    public void setAlvo(boolean alvo) {
        this.alvo = alvo;
    }

    /**
     * Returns the name of division
     *
     * @return the name of divsion
     */
    @Override
    public String toString() {
        return nome;
    }
}
