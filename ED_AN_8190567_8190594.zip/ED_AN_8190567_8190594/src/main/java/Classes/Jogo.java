package Classes;

import API.Exceptions.EmptyCollectionException;
import API.Graph.GraphNode;
import API.Graph.Graph_List;
import API.Leitura.APILeitura;
import Interfaces.JogoADT;
import java.util.Iterator;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * Jogo is the class that serves to play on manual/automatic mode and also saves
 * all the information about the map.
 */
public class Jogo implements JogoADT {

    private String cod_missao;
    private int versao;
    private String[] edificio;
    private String[][] ligacoes;
    private Inimigo[] inimigos;
    private String[] entradas_saidas;
    private Alvo alvo;
    private Graph_List<Divisao> graph;
    private GraphNode<Divisao> current;
    private ToCruz toCruz;
    private APILeitura apiLeitura;

    public Jogo(String cod_missao, int versao, String[] edificio, String[][] ligacoes, Inimigo[] inimigos, String[] entradas_saidas, Alvo alvo) {
        this.cod_missao = cod_missao;
        this.versao = versao;
        this.edificio = edificio;
        this.ligacoes = ligacoes;
        this.inimigos = inimigos;
        this.entradas_saidas = entradas_saidas;
        this.alvo = alvo;
        this.current = new GraphNode<>();
        graph = new Graph_List<>();
        toCruz = new ToCruz();
        start();
        apiLeitura = new APILeitura();
    }

    /**
     * Insert all the divisions/Conections into a graph
     */
    private void start() {
        inserirDivisoes();
        inserirLigacoes();
    }

    /**
     * Starts the game in automaticc mode
     *
     * @throws EmptyCollectionException - if collection is empty
     */
    @Override
    public void startGameAutomatic() throws EmptyCollectionException {
        ToCruz[] toCruzSimulation = new ToCruz[entradas_saidas.length];
        int bestStart = 0;
        String divisao = "";
        System.out.println("*---------------MAPA---------------*");
        System.out.println("###########################################");
        for (int i = 0; i < graph.size(); i++) {

            System.out.println("Divisão: " + graph.getVertices()[i].getElement().toString());
            if (graph.getVertices()[i].getElement().isInimigos()) {
                System.out.println("--------------------");
                System.out.println("Inimigos: ");
                System.out.println("********************");
                for (int j = 0; j < graph.getVertices()[i].getElement().size(); j++) {
                    System.out.println("Nome:" + graph.getVertices()[i].getElement().getInimigos()[j].getNome());
                    System.out.println("Poder:" + graph.getVertices()[i].getElement().getInimigos()[j].getPoder());
                    System.out.println("--------------------");
                }
            }
            System.out.print("Ligações: ");
            for (int j = 0; j < graph.getVertices()[i].size(); j++) {

                System.out.print(graph.getVertices()[graph.getVertices()[i].getAdjVertex()[j].getPosicion()].getElement().toString() + "; ");
            }

            System.out.println("\n###########################################");
        }
        System.out.println("*---------------SIMULAÇÕES---------------*");
        for (int i = 0; i < entradas_saidas.length; i++) {
            toCruzSimulation[i] = new ToCruz();
            System.out.println("###########################################");
            System.out.println("*---------------Simulação " + (i + 1) + "---------------*");
            System.out.println("###########################################");
            System.out.print("Entrada - > ");
            current = getEntrada(entradas_saidas[i]);

            Iterator<String> itr1 = graph.iteratorShortestPath(current.getElement(), new Divisao(alvo.getDivisao()));
            while (itr1.hasNext() && !toCruzSimulation[i].isDead()) {
                divisao = itr1.next();
                System.out.print(divisao + "->");
                toCruzSimulation[i].levouBala(pesquisaInimigo(divisao));
            }
            if (divisao.equals(alvo.getDivisao())) {
                System.out.println("\n######");
                System.out.println("Tó Cruz Apanhou o alvo!");
                System.out.println("######");
            }

            Iterator<String> itr2 = graph.iteratorShortestPath(new Divisao(alvo.getDivisao()), current.getElement());
            while (itr2.hasNext() && !toCruzSimulation[i].isDead()) {
                divisao = itr2.next();
                System.out.print(divisao + "->");
                toCruzSimulation[i].levouBala(pesquisaInimigo(divisao));
            }
            System.out.println("\n######");
            if (divisao.equals(entradas_saidas[i])) {
                if (toCruzSimulation[i].getVida() == toCruzSimulation[i].getTAM_VIDA()) {
                    System.out.println("Tó Cruz finalizou a missão com sucesso!");
                } else {
                    System.out.println("Tó Cruz falhou na missão!\nVida restante: " + toCruzSimulation[i].getVida());
                }

            }
            System.out.println("######");
        }

        for (int i = 1; i < toCruzSimulation.length; i++) {
            if (toCruzSimulation[bestStart].getVida() < toCruzSimulation[i].getVida()) {
                bestStart = i;
            }
        }

        System.out.println("A melhor entrada/saida é -> " + entradas_saidas[bestStart]);
        System.out.println("######");

    }

    /**
     * Draw the divisions
     *
     * @param divisao - Division thats its gonna be drawed
     * @param n - Division number(choice)
     * @return - Draw of the division
     */
    private String drawDivisao(Divisao divisao, int n) {
        String nomeDiv = (n + "->" + divisao.toString());
        if (divisao.isAlvo()) {
            nomeDiv += "(Alvo)";
        }
        if (divisao.isInimigos()) {
            return (nomeDiv + "\n"
                    + " ________________\n"
                    + "|                |\n"
                    + "|                |\n"
                    + "|        0       |\n"
                    + "|     {|/V\\      |\n"
                    + "|       /¯\\      |\n"
                    + "|                |\n"
                    + "|________________|\n");
        }

        return (nomeDiv + "\n"
                + " ________________\n"
                + "|                |\n"
                + "|                |\n"
                + "|                |\n"
                + "|                |\n"
                + "|                |\n"
                + "|                |\n"
                + "|________________|\n");
    }

    /**
     * Draw the division that toCruz is
     *
     * @param divisao - Division thats its gonna be drawed
     * @return Draw of division with toCruz
     */
    private String drawDivisaoToCruz(Divisao divisao) {

        String alvo = "\tAlvo: ";
        if (toCruz.isAlvo()) {
            alvo += "Adquirido";
        } else {
            alvo += this.alvo.getDivisao();
        }
        if (divisao.isInimigos()) {
            if (divisao.isAlvo()) {
                return (divisao.toString() + "(Alvo)" + "\n"
                        + " ____________________________\n"
                        + "|                            |\n"
                        + "|                            |\n"
                        + "|        0           0       |\n"
                        + "|       /V\\ - - - {|/V\\      |\n"
                        + "|       /¯\\         /¯\\      |        \n"
                        + "|                            | \n"
                        + "|____________________________|\n"
                        + "Vida: " + toCruz.getVida() + alvo + "\n");
            }
            return (divisao.toString() + "\n"
                    + " ____________________________\n"
                    + "|                            |\n"
                    + "|                            |\n"
                    + "|        0           0       |\n"
                    + "|       /V\\ - - - {|/V\\      |\n"
                    + "|       /¯\\         /¯\\      |        \n"
                    + "|                            | \n"
                    + "|____________________________|\n"
                    + "Vida: " + toCruz.getVida() + alvo + "\n");
        }

        if (divisao.isAlvo()) {
            return (divisao.toString() + "(Alvo)" + "\n"
                    + " ____________________________\n"
                    + "|                            |\n"
                    + "|                            |\n"
                    + "|        0                   |\n"
                    + "|       /V\\                  |\n"
                    + "|       /¯\\                  |\n"
                    + "|                            |\n"
                    + "|____________________________|\n"
                    + "Vida: " + toCruz.getVida() + alvo + "\n");
        }

        return (divisao.toString() + "\n"
                + " ____________________________\n"
                + "|                            |\n"
                + "|                            |\n"
                + "|        0                   |\n"
                + "|       /V\\                  |\n"
                + "|       /¯\\                  |\n"
                + "|                            |\n"
                + "|____________________________|\n"
                + "Vida: " + toCruz.getVida() + alvo + "\n");
    }

    /**
     * Start the game on manual mode
     *
     * @return The mission brief
     */
    @Override
    public MissaoManual startGameManual() {
        int choice = 0;
        String path = "";
        int nextNode = 0;

        for (int i = 0; i < entradas_saidas.length; i++) {
            System.out.println("\n" + i + " -> " + entradas_saidas[i]);
        }

        choice = apiLeitura.readInt(0, entradas_saidas.length - 1, "Insira a entrada:");
        current = getEntrada(entradas_saidas[choice]);

        path += current.getElement().toString() + "-> ";
        boolean exit = false;
        if (current.getElement().isInimigos()) {
            toCruz.levouBala(current.getElement().danoInimigos());
        }

        System.out.println(drawDivisaoToCruz(current.getElement()));

        while (toCruz.getVida() > 0 && !exit) {

            for (int i = 0; i < current.size(); i++) {

                System.out.println(drawDivisao(graph.getVertices()[current.getAdjVertex()[i].getPosicion()].getElement(), i));
            }

            nextNode = apiLeitura.readInt(0, current.size() - 1, "Insira a próxima divisao");

            current = graph.getVertices()[current.getAdjVertex()[nextNode].getPosicion()];
            path += current.getElement().toString() + "-> ";

            if (current.getElement().isAlvo() && !toCruz.isAlvo()) {
                toCruz.setAlvo(true);
                System.out.println("Apanhas-te o alvo");
                current.getElement().setAlvo(false);
            }
            if (current.getElement().isInimigos()) {
                toCruz.levouBala(current.getElement().danoInimigos());
            }
            if (current.getElement().isEntrada_saida()) {
                if (toCruz.isAlvo()) {
                    System.out.println("To Cruz, quer realmente sair? Já tem alvo");
                } else {
                    System.out.println("To Cruz, quer realmente sair? Ainda não tem o alvo");
                }

                choice = apiLeitura.readInt(0, 1, "0->Não\n1->Sim");
                if (choice == 1) {
                    exit = true;
                }
            }
            System.out.println(drawDivisaoToCruz(current.getElement()));
        }

        if (toCruz.isAlvo() && !toCruz.isDead()) {
            System.out.println(" ____________________________\n"
                    + "|       Tó Cruz Ganhou       |\n"
                    + "|                            |\n"
                    + "|             0              |\n"
                    + "|            /V\\             |\n"
                    + "|            /¯\\             |\n"
                    + "|          Easy Win          |\n"
                    + "|____________________________|");
        } else if (!toCruz.isAlvo() && !toCruz.isDead()) {
            System.out.println(" ____________________________\n"
                    + "|       Tó Cruz Perdeu       |\n"
                    + "|                            |\n"
                    + "|             0              |\n"
                    + "|            /V\\             |\n"
                    + "|            /¯\\             |                  \n"
                    + "|       Saiu sem o alvo      |\n"
                    + "|____________________________|");
        } else {
            System.out.println(" ____________________________\n"
                    + "|                            |\n"
                    + "|     Tó Cruz morreu         |\n"
                    + "|                            |\n"
                    + "|          >->o              |\n"
                    + "|                            |\n"
                    + "|        Game Over           |\n"
                    + "|____________________________|");
        }
        int restLife = toCruz.getVida();
        toCruz.setVida(toCruz.getTAM_VIDA());

        return new MissaoManual(path, restLife);
    }

    /**
     * finds the Node(division) that is associeted with the name
     *
     * @param entrada - name of division
     * @return return the node
     */
    private GraphNode getEntrada(String entrada) {
        boolean flag = false;
        GraphNode<Divisao> temp = new GraphNode();
        Divisao tempDiv = new Divisao(entrada);

        for (int i = 0; i < graph.getVertices().length && !flag; i++) {
            if (tempDiv.compareTo(graph.getVertices()[i].getElement()) == 0) {
                temp = graph.getVertices()[i];
                flag = true;
            }
        }
        return temp;
    }

    /**
     * Verifies if the name of division is a entry/exit
     *
     * @param divisao - name of division
     * @return true if is a entry/exit,false if not.
     */
    private boolean verificaoEntradaSaida(String divisao) {
        boolean flag = false;
        for (int i = 0; i < entradas_saidas.length && !flag; i++) {
            if (divisao.equals(entradas_saidas[i])) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * Insert all the divisions into a graph
     */
    private void inserirDivisoes() {
        int numDivisoes = edificio.length;
        int numInimigos = inimigos.length;
        Divisao temp;

        for (int i = 0; i < numDivisoes; i++) {
            temp = new Divisao(edificio[i]);
            for (int j = 0; j < numInimigos; j++) {
                if (inimigos[j].getDivisao().equals(edificio[i])) {
                    temp.addInimigo(inimigos[j]);
                }
            }
            temp.setEntrada_saida(verificaoEntradaSaida(edificio[i]));
            temp.setAlvo(alvo.getDivisao().equals(edificio[i]));
            graph.addVertex(temp);
        }
    }

    /**
     * Insert all the edges(division conections) into a graph
     */
    private void inserirLigacoes() {
        int height = ligacoes.length;
        int peso;
        for (int i = 0; i < height; i++) {
            peso = pesquisaInimigo(ligacoes[i][0]);
            graph.addEdge(new Divisao(ligacoes[i][0]), new Divisao(ligacoes[i][1]), peso);
            peso = pesquisaInimigo(ligacoes[i][1]);
            graph.addEdge(new Divisao(ligacoes[i][1]), new Divisao(ligacoes[i][0]), peso);
        }

    }

    /**
     * Sum all the power of all enemys in a division
     *
     * @param divisao - name of division
     * @return total power of enemys inside a division
     */
    private int pesquisaInimigo(String divisao) {
        int peso = 0;
        for (int i = 0; i < inimigos.length; i++) {
            if (inimigos[i].getDivisao().equals(divisao)) {
                peso += inimigos[i].getPoder();
            }
        }
        return peso;
    }

    /**
     * Returns the codMission
     *
     * @return the codMission
     */
    public String getCod_missao() {
        return cod_missao;
    }

    /**
     * Set the codMission
     *
     * @param cod_missao - codMission
     */
    public void setCod_missao(String cod_missao) {
        this.cod_missao = cod_missao;
    }

    /**
     * Get the game version
     *
     * @return game version
     */
    public int getVersao() {
        return versao;
    }

    /**
     * Set the version of the game
     *
     * @param versao - version
     */
    public void setVersao(int versao) {
        this.versao = versao;
    }

    /**
     * Get all the name of division into a array of String
     *
     * @return array with division names
     */
    public String[] getEdificio() {
        return edificio;
    }

    /**
     * Get all the connections of all division
     *
     * @return array with all division connections
     */
    public String[][] getLigacoes() {
        return ligacoes;
    }

    /**
     * Get all the enemys
     *
     * @return array of Inimigo
     */
    public Inimigo[] getInimigos() {
        return inimigos;
    }

    /**
     * Get all the entrys/exits
     *
     * @return array with all entry/exits
     */
    public String[] getEntradas_saidas() {
        return entradas_saidas;
    }

    /**
     * Get the Alvo
     *
     * @return alvo
     */
    public Alvo getAlvo() {
        return alvo;
    }

    /**
     * Set the alvo
     *
     * @param alvo - alvo
     */
    public void setAlvo(Alvo alvo) {
        this.alvo = alvo;
    }

    /**
     * Get the graph(division)
     *
     * @return Graph
     */
    public Graph_List<Divisao> getGraph() {
        return graph;
    }

}
