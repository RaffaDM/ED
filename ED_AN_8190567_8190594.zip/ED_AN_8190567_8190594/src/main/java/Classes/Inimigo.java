package Classes;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * Inimigo is the enemy inside of the division, so they will do damage to To
 * Cruz.
 */
public class Inimigo {

    private String nome;
    private int poder;
    private String divisao;

    public Inimigo(String nome, int poder, String divisao) {
        this.nome = nome;
        this.poder = poder;
        this.divisao = divisao;
    }

    public Inimigo() {
        this.nome = "";
        this.poder = 0;
        this.divisao = "";
    }

    /**
     * Returns the Name of the enemy
     *
     * @return Name of enemy
     */
    public String getNome() {
        return nome;
    }

    /**
     * Set the Name of the enemy
     *
     * @param nome - Name of enemy
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Returns the power of enemy
     *
     * @return - Power of enemy
     */
    public int getPoder() {
        return poder;
    }

    /**
     * Set the power of enemy
     *
     * @param poder - power of enemy
     */
    public void setPoder(int poder) {
        this.poder = poder;
    }

    /**
     * Get the division of the enemy
     *
     * @return name of division
     */
    public String getDivisao() {
        return divisao;
    }

    /**
     * Set the division of the enemy
     *
     * @param divisao - name of division
     */
    public void setDivisao(String divisao) {
        this.divisao = divisao;
    }

}
