package Classes;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 * Its the path that toCruz did with the life left
 *
 */
public class MissaoManual {

    private String path;
    private int vidaRestante;

    public MissaoManual(String path, int vidaRestante) {
        this.path = path;
        this.vidaRestante = vidaRestante;
    }

    public MissaoManual() {
    }

    /**
     * Get the path
     *
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * Set the path
     *
     * @param path - path
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Get the left life of toCruz
     *
     * @return life of toCruz
     */
    public int getVidaRestante() {
        return vidaRestante;
    }

    /**
     * Set tje life
     *
     * @param vidaRestante - life
     */
    public void setVidaRestante(int vidaRestante) {
        this.vidaRestante = vidaRestante;
    }

}
