package Classes;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * Alvo is the object that To Cruz need to get.
 */
public class Alvo {

    private String divisao;
    private String tipo;

    public Alvo(String divisao, String tipo) {
        this.divisao = divisao;
        this.tipo = tipo;
    }

    public Alvo() {
        this.divisao = "";
        this.tipo = "";
    }

    /**
     * Returns the name of the division
     *
     * @return name of division
     */
    public String getDivisao() {
        return divisao;
    }

    /**
     * Set the name of the division
     *
     * @param divisao - Name of the division
     */
    public void setDivisao(String divisao) {
        this.divisao = divisao;
    }

    /**
     * Get the type of alvo
     *
     * @return Type of alvo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Set the type alvo
     *
     * @param tipo - Type of alvo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
