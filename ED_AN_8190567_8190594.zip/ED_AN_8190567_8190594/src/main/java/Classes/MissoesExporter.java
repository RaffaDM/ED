package Classes;

import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONArray;
import API.Exceptions.EmptyCollectionException;
import org.json.simple.JSONObject;
import API.PriorityQueue.PriorityQueue;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 *
 * This class export all the manual missons made by toCruz to json File
 */
public class MissoesExporter {

    public MissoesExporter() {
    }

    /**
     * Export all the manual missions to a json file
     *
     * @param missoesRealizadas - all the manual missions
     * @throws EmptyCollectionException - throws a empty collection
     * @throws IOException - throws a input/output exception
     */
    public void export(MissoesRealizadas missoesRealizadas) throws EmptyCollectionException, IOException {
        JSONObject mission = new JSONObject();
        mission.put("cod-missao", missoesRealizadas.getCod_missao());
        mission.put("versao", missoesRealizadas.getVersao());

        PriorityQueue<MissaoManual> resultados = missoesRealizadas.getMissoesManuais();
        JSONArray jsonArray = new JSONArray();
        while (resultados.size() != 0) {
            MissaoManual missoesManuais = resultados.removeNext();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("Caminho", missoesManuais.getPath());
            jsonObject.put("Vida", missoesManuais.getVidaRestante());
            jsonArray.add(jsonObject);
        }
        mission.put("MissoesManuais", jsonArray);
        FileWriter file = new FileWriter("MissoesManuais/" + missoesRealizadas.getCod_missao() + "_Versao" + missoesRealizadas.getVersao() + ".json");
        file.write(mission.toJSONString());
        file.close();
    }

    public MissoesRealizadas importer(String fileName) throws FileNotFoundException, IOException, ParseException {
        MissoesRealizadas m1 = new MissoesRealizadas();

        JSONParser parser = new JSONParser();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
        JSONObject jsonObj = (JSONObject) parser.parse(reader);
        m1.setCod_missao((String) jsonObj.get("cod-missao"));
        m1.setVersao((int) jsonObj.get("versao"));
        JSONObject obj;
        JSONArray MissoesManuais = (JSONArray) jsonObj.get("MissoesManuais");
        String[] path = new String[MissoesManuais.size()];

        for (int i = 0; i < MissoesManuais.size(); i++) {
            obj = (JSONObject) MissoesManuais.get(i);
            m1.addMissaoManual(new MissaoManual((String) obj.get("Caminho"), (int) obj.get("Vida")));
        }

        return m1;
    }
}
