package Classes;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import org.json.simple.*;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Integer.parseInt;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*
* Nome: Rafael Duarte Meireles Pacheco Moreira
* Número: 8190567
* Turma: LSIRC
*
* Nome: Sérgio Manuel Monteiro Oliveira
* Número: 8190594
* Turma: LSIRC
 */
/**
 * 
 * ReadMap, serves to read JSON files and transform them to a playable map.
 */
public class ReadMap {

    private Jogo jogo;
    private String fileName;

    /**
     * Reads a valid map file, saving all on a Jogo class
     *
     * @param fileName- file location
     * @throws FileNotFoundException the file dont exist
     * @throws IOException the input isn't valid
     * @throws ParseException can't parse the file
     */
    public ReadMap(String fileName) throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
        JSONObject jsonObj = (JSONObject) parser.parse(reader);
        
        String cod_missao = (String) jsonObj.get("cod-missao");
        int versao = parseInt(jsonObj.get("versao").toString());

        JSONArray arrEdificio = (JSONArray) jsonObj.get("edificio");
        String[] edificio = new String[arrEdificio.size()];

        for (int i = 0; i < arrEdificio.size(); i++) {
            edificio[i] = arrEdificio.get(i).toString();
        }
        JSONArray arrLigacoes = (JSONArray) jsonObj.get("ligacoes");
        JSONArray arrDivisoes = null;
        String[][] ligacoes = new String[arrLigacoes.size()][2];
        for (int i = 0; i < arrLigacoes.size(); i++) {
            arrDivisoes = (JSONArray) arrLigacoes.get(i);
            for (int j = 0; j < arrDivisoes.size(); j++) {
                ligacoes[i][j] = arrDivisoes.get(j).toString();
            }
        }
        JSONArray arrInimigos = (JSONArray) jsonObj.get("inimigos");
        Inimigo[] inimigos = new Inimigo[arrInimigos.size()];
        JSONObject tempIni;
        for (int i = 0; i < arrInimigos.size(); i++) {
            inimigos[i] = new Inimigo();
            tempIni = (JSONObject) arrInimigos.get(i);
            inimigos[i].setNome(tempIni.get("nome").toString());
            inimigos[i].setPoder(parseInt(tempIni.get("poder").toString()));
            inimigos[i].setDivisao(tempIni.get("divisao").toString());
        }

        JSONArray arrEntradas = (JSONArray) jsonObj.get("entradas-saidas");
        String[] entradas_Saidas = new String[arrEntradas.size()];
        for (int i = 0; i < arrEntradas.size(); i++) {
            entradas_Saidas[i] = arrEntradas.get(i).toString();
        }
        JSONObject jsonAlvo = (JSONObject) jsonObj.get("alvo");
        Alvo alvo = new Alvo();
        alvo.setDivisao(jsonAlvo.get("divisao").toString());
        alvo.setTipo(jsonAlvo.get("tipo").toString());

        jogo = new Jogo(cod_missao, versao, edificio, ligacoes, inimigos, entradas_Saidas, alvo);

    }

    /**
     * Returns the map
     *
     * @return the mapGame
     */
    public Jogo getMapa() {
        return jogo;
    }

    /**
     * Gets the filename
     *
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

}
